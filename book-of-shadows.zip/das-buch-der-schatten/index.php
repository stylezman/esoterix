<html>
    <head>
        <title>&clubs; Das Buch der Schatten &clubs;</title>
        <link rel="stylesheet" href="stylesheet.css">
    </head>
    <body>
        <div class="wrapper">
            <div id="navigation">
            	<a href="index.php">Hauptseite</a>&nbsp;
                <a href="index.php?page=add">Eintragen</a>&nbsp;
                <a href="index.php?page=list">Inhalt anzeigen</a>
            </div>
            <div id="content">
            	<?php if(isset($_GET['page']))
            	{
            	    $db = new MySQLi("localhost","username_of_database","password_of_database","database_name");
            	}else{
            	    echo "<br><br><br>Um einen neuen Ritus hinzuzuf&uuml;gen, bitte die Enter-Taste bei jedem Absatz, den Du in deinem Text hast, benutzen, es wird dann genau umgebrochen, wo Du einmal Enter gedr&uuml;ckt hast (:<br>Der Ritus wird nach Sichtung freigeschaltet.";
            	}
            	if($_GET['page'] == 'add'){
            	    if(!isset($_POST['eintragen'])){
            	    echo "<form action=\"index.php?page=add\" method=\"post\">Titel:&nbsp;<input type=\"text\" name=\"titel\" required=\"required\" /><br>Ritus:&nbsp;<textarea name=\"ritus\" required=\"required\"></textarea><br><input type=\"submit\" name=\"eintragen\" value=\"Hinzuf&uuml;gen\" /></form>";
            	    }else{            	        
            	        $titel = htmlentities($_POST['titel']);
            	        $ritus = htmlentities($_POST['ritus']);
            	        $query = "INSERT INTO dbds(Titel,Ritus) VALUES('$titel','$ritus');";
            	        $db->query($query);            	
            	    }
            	}elseif($_GET['page'] == 'list'){
            	    $query = "SELECT Titel,Ritus FROM dbds WHERE aktiv = 'J' ORDER BY id DESC;";
            	    $result = $db->query($query);
            	    while($row=$result->fetch_assoc()){
            	        echo "<div id=\"ritus\"><h2>$row[Titel]</h2><pre>$row[Ritus]</pre></div>";
            	    }
            	}
            	    ?>
            </div>
       </div>
    </body>
</html>